Net-Work Documentation
======================

**Net-Work** is a Python library for distributed computing in environments
with a shared filesystem between worker nodes.

Contents
--------

.. toctree::

   api
